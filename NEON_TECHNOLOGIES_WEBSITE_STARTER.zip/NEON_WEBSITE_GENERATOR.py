from pathlib import Path
import webbrowser

# NEON TECHNOLOGIES website generator
# Run this file with Python. It creates a ready-to-upload "neon_site" folder.

output_dir = Path(__file__).resolve().parent / "neon_site"
output_dir.mkdir(exist_ok=True)

website = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="theme-color" content="#070a12">
<meta name="description" content="NEON Technologies — building bold digital experiences, useful software, and experimental projects.">
<title>NEON Technologies | Build Beyond</title>
<style>
:root{--bg:#070a12;--panel:#0d1321;--panel2:#101a2b;--line:#1c2a40;--text:#edf5ff;--muted:#91a4bf;--cyan:#41f5e6;--blue:#4b8dff;--pink:#f45bff}
*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:radial-gradient(ellipse at 80% -10%,#122d48 0,transparent 38%),radial-gradient(ellipse at 5% 35%,#151037 0,transparent 28%),var(--bg);color:var(--text);font-family:Inter,Segoe UI,Arial,sans-serif;line-height:1.6}a{color:inherit;text-decoration:none}.wrap{width:min(1120px,92%);margin:auto}.nav{display:flex;align-items:center;justify-content:space-between;padding:20px 0;border-bottom:1px solid #ffffff12}.brand{display:flex;gap:11px;align-items:center;font-weight:850;letter-spacing:1.2px}.logo{width:38px;height:38px;border:1px solid var(--cyan);border-radius:11px;display:grid;place-items:center;color:var(--cyan);font-weight:900;box-shadow:0 0 22px #41f5e625}.navlinks{display:flex;gap:24px;color:var(--muted);font-size:14px}.navlinks a:hover{color:var(--cyan)}.hero{padding:86px 0 70px;display:grid;grid-template-columns:1.25fr .75fr;gap:42px;align-items:center}.eyebrow{color:var(--cyan);font-size:12px;font-weight:800;letter-spacing:3px;text-transform:uppercase}.hero h1{font-size:clamp(42px,7vw,76px);line-height:1.02;letter-spacing:-2.7px;margin:17px 0}.gradient{background:linear-gradient(95deg,var(--cyan),#80a7ff 55%,var(--pink));-webkit-background-clip:text;background-clip:text;color:transparent}.hero p{color:var(--muted);font-size:17px;max-width:620px}.actions{display:flex;gap:12px;flex-wrap:wrap;margin-top:28px}.btn{display:inline-flex;align-items:center;justify-content:center;padding:12px 18px;border-radius:10px;border:1px solid var(--line);font-weight:750;font-size:14px;transition:.2s}.btn.primary{background:var(--cyan);color:#031016;border-color:var(--cyan)}.btn:hover{transform:translateY(-2px);box-shadow:0 8px 30px #41f5e620}.visual{min-height:320px;border:1px solid #41f5e63a;border-radius:24px;background:linear-gradient(145deg,#102332dd,#111026dd);position:relative;overflow:hidden;display:grid;place-items:center;box-shadow:0 0 65px #2468ff12}.orb{width:190px;height:190px;border-radius:50%;border:1px solid #41f5e688;box-shadow:inset 0 0 38px #41f5e61c,0 0 55px #41f5e622;display:grid;place-items:center;position:relative}.orb:before,.orb:after{content:"";position:absolute;border:1px solid #7d8dff66;border-radius:50%;inset:-25px;transform:rotateX(65deg) rotate(-25deg)}.orb:after{inset:-48px;transform:rotateX(65deg) rotate(35deg);border-color:#f45bff55}.orb span{font-size:48px;font-weight:950;letter-spacing:-5px;color:var(--cyan);text-shadow:0 0 25px #41f5e688}.float-tag{position:absolute;padding:8px 11px;border:1px solid #ffffff20;background:#070a12cc;border-radius:8px;color:#c6d8ed;font-size:11px;letter-spacing:1px}.tag1{top:22px;left:20px}.tag2{right:18px;bottom:24px}.section{padding:55px 0}.section-head{display:flex;align-items:end;justify-content:space-between;gap:20px;margin-bottom:24px}.section h2{font-size:clamp(27px,4vw,39px);line-height:1.15;margin:8px 0}.section-head p,.muted{color:var(--muted)}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:16px}.card{padding:23px;border:1px solid var(--line);border-radius:16px;background:linear-gradient(145deg,#101827d9,#0a0f1bdf);min-height:205px;transition:.22s}.card:hover{transform:translateY(-4px);border-color:#41f5e66b}.iconbox{width:42px;height:42px;display:grid;place-items:center;border-radius:12px;background:#41f5e612;border:1px solid #41f5e62e;font-size:21px}.card h3{margin:17px 0 7px;font-size:19px}.card p{color:var(--muted);font-size:14px;margin:0 0 16px}.pill{display:inline-block;font-size:11px;color:var(--cyan);border:1px solid #41f5e63d;background:#41f5e60b;padding:4px 8px;border-radius:999px}.about{display:grid;grid-template-columns:.8fr 1.2fr;gap:30px;align-items:center}.aboutbox{padding:26px;border:1px solid var(--line);border-radius:18px;background:var(--panel)}.stats{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-top:18px}.stat{padding:15px;border-radius:12px;background:#ffffff05;border:1px solid #ffffff10}.stat strong{display:block;font-size:20px;color:var(--cyan)}.stat span{font-size:11px;color:var(--muted)}.contact{border:1px solid #41f5e637;border-radius:20px;padding:30px;background:linear-gradient(120deg,#10232b,#111127);display:flex;align-items:center;justify-content:space-between;gap:20px}.contact h2{margin:5px 0 8px}.contact p{color:var(--muted);margin:0}.footer{padding:26px 0 36px;margin-top:50px;border-top:1px solid #ffffff12;color:var(--muted);font-size:12px;display:flex;justify-content:space-between;gap:14px;flex-wrap:wrap}.footer strong{color:var(--text)}.note{font-size:12px;color:#71839d;margin-top:14px}
@media(max-width:780px){.hero{grid-template-columns:1fr;padding:58px 0 35px}.visual{min-height:270px}.grid{grid-template-columns:1fr}.about{grid-template-columns:1fr}.navlinks{gap:12px;font-size:12px}.navlinks a:nth-child(2){display:none}.section-head{display:block}.contact{display:block}.contact .btn{margin-top:18px}.hero h1{letter-spacing:-1.5px}}
</style>
</head>
<body>
<header class="wrap">
  <nav class="nav" aria-label="Main navigation">
    <a class="brand" href="#home"><span class="logo">N</span><span>NEON <span class="gradient">TECHNOLOGIES</span></span></a>
    <div class="navlinks"><a href="#products">Products</a><a href="#projects">Projects</a><a href="#about">About</a><a href="#contact">Contact</a></div>
  </nav>
</header>
<main>
<section class="hero wrap" id="home">
  <div>
    <div class="eyebrow">Independent ideas. Digital impact.</div>
    <h1>We build<br><span class="gradient">beyond limits.</span></h1>
    <p>Welcome to NEON Technologies — a growing technology initiative exploring software, interactive experiences, and practical digital tools. Small beginnings. Big ambition.</p>
    <div class="actions"><a class="btn primary" href="#products">Explore our work ↗</a><a class="btn" href="#about">Meet NEON</a></div>
    <div class="note">INNOVATION • SOFTWARE • EXPERIMENTS</div>
  </div>
  <div class="visual" aria-label="Abstract neon technology artwork"><div class="float-tag tag1">SYSTEM ONLINE</div><div class="orb"><span>N//</span></div><div class="float-tag tag2">BUILD · TEST · IMPROVE</div></div>
</section>
<section class="section wrap" id="products">
  <div class="section-head"><div><div class="eyebrow">The product lab</div><h2>Made for curious minds.</h2></div><p>Useful tools. Clear purpose.<br>Built one version at a time.</p></div>
  <div class="grid">
    <article class="card"><div class="iconbox">📈</div><h3>NEON TRADELAB</h3><p>A paper-trading simulator concept for learning market basics with virtual money — not real-money trading.</p><span class="pill">PAPER TRADING</span></article>
    <article class="card"><div class="iconbox">🤖</div><h3>NEON AI LAB</h3><p>Experiments in desktop assistants, useful automation, and approachable human-computer interaction.</p><span class="pill">EXPERIMENTAL</span></article>
    <article class="card"><div class="iconbox">🧪</div><h3>PROJECT ATOM</h3><p>A virtual electronics workbench concept for exploring circuits and learning through simulation.</p><span class="pill">LEARNING TOOL</span></article>
  </div>
</section>
<section class="section wrap" id="projects">
  <div class="section-head"><div><div class="eyebrow">Project showcase</div><h2>Ideas in progress.</h2></div><p>Every build is a chance<br>to learn something new.</p></div>
  <div class="grid">
    <article class="card"><div class="iconbox">🌌</div><h3>PROJECT GOD MODE</h3><p>A desktop concept exploring a cosmic, interactive digital universe.</p><span class="pill">CONCEPT / PROTOTYPE</span></article>
    <article class="card"><div class="iconbox">🕹️</div><h3>GAME DEVELOPMENT</h3><p>Experiments with gameplay, visual effects, and arcade-style experiences.</p><span class="pill">IN DEVELOPMENT</span></article>
    <article class="card"><div class="iconbox">⚙️</div><h3>ENGINEERING LAB</h3><p>Small practical experiments designed to make technology easier to understand.</p><span class="pill">R&D</span></article>
  </div>
</section>
<section class="section wrap" id="about">
  <div class="about">
    <div><div class="eyebrow">Who we are</div><h2>Built with curiosity.<br><span class="gradient">Driven by progress.</span></h2></div>
    <div class="aboutbox"><p class="muted">NEON Technologies is an independent, early-stage technology initiative focused on learning by building. Our goal is to turn ideas into useful prototypes, share progress honestly, and keep improving with every release.</p><div class="stats"><div class="stat"><strong>01</strong><span>BUILD SMALL</span></div><div class="stat"><strong>02</strong><span>TEST HONESTLY</span></div><div class="stat"><strong>03</strong><span>KEEP IMPROVING</span></div></div></div>
  </div>
</section>
<section class="section wrap" id="contact">
  <div class="contact"><div><div class="eyebrow">Let's connect</div><h2>Have an idea? Let's build.</h2><p>For questions, feedback, or collaborations, visit our main NEON Technologies HQ.</p></div><a class="btn primary" href="https://sites.google.com/view/neon-technologies-hq/home" target="_blank" rel="noopener noreferrer">Visit NEON HQ ↗</a></div>
</section>
</main>
<footer class="wrap footer"><div><strong>NEON TECHNOLOGIES</strong><br>Build beyond. Learn by doing.</div><div>Independent project • Educational prototypes<br>© <span id="year">2026</span> NEON Technologies</div></footer>
<script>document.getElementById("year").textContent = new Date().getFullYear();</script>
</body>
</html>
"""
index_file = output_dir / "index.html"
index_file.write_text(website, encoding="utf-8")

print("=" * 58)
print(" NEON TECHNOLOGIES WEBSITE FILES CREATED SUCCESSFULLY!")
print("=" * 58)
print(f"\nFolder: {output_dir}")
print(f"Main file: {index_file}")
print("\nNEXT STEPS:")
print("1. Open the 'neon_site' folder.")
print("2. Double-click index.html to preview the website.")
print("3. Upload index.html to your GitHub repository.")
print("4. On GitHub: Settings > Pages > Deploy from a branch.")
print("5. Select branch 'main', folder '/ (root)', then Save.")
print("\nNo extra Python packages are required.")
try:
    webbrowser.open(index_file.as_uri())
except Exception:
    pass
input("\nPress Enter to close this window...")
